package com.mindtree.employeemanagementapp.exception;

public class EmployeeManagementAppException extends Exception {

	private static final long serialVersionUID = 8102542073871692459L;

	public EmployeeManagementAppException() {
		// TODO Auto-generated constructor stub
	}

	public EmployeeManagementAppException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public EmployeeManagementAppException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public EmployeeManagementAppException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public EmployeeManagementAppException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
