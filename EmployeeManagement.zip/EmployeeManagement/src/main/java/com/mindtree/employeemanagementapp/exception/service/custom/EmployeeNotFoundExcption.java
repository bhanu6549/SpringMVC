package com.mindtree.employeemanagementapp.exception.service.custom;

import com.mindtree.employeemanagementapp.exception.service.EmployeeManagementAppServiceException;

public class EmployeeNotFoundExcption extends EmployeeManagementAppServiceException {

	private static final long serialVersionUID = 8482389049804630343L;

	public EmployeeNotFoundExcption() {
		// TODO Auto-generated constructor stub
	}

	public EmployeeNotFoundExcption(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public EmployeeNotFoundExcption(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public EmployeeNotFoundExcption(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public EmployeeNotFoundExcption(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
