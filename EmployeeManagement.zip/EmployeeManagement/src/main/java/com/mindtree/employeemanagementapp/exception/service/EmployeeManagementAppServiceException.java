package com.mindtree.employeemanagementapp.exception.service;

import com.mindtree.employeemanagementapp.exception.EmployeeManagementAppException;

public class EmployeeManagementAppServiceException extends EmployeeManagementAppException {

	private static final long serialVersionUID = -6293282586786044421L;

	public EmployeeManagementAppServiceException() {
		// TODO Auto-generated constructor stub
	}

	public EmployeeManagementAppServiceException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public EmployeeManagementAppServiceException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public EmployeeManagementAppServiceException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public EmployeeManagementAppServiceException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
