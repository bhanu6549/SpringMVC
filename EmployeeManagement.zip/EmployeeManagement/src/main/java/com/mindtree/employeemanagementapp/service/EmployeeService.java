package com.mindtree.employeemanagementapp.service;

import java.util.List;
import java.util.Set;

import com.mindtree.employeemanagementapp.entity.Employee;
import com.mindtree.employeemanagementapp.exception.service.EmployeeManagementAppServiceException;

public interface EmployeeService {
	public Employee addEmployeeData(Employee employee) throws EmployeeManagementAppServiceException;

	public Set<Employee> getAllEmployee() throws EmployeeManagementAppServiceException;

	public Employee getEmployeeById(int id) throws EmployeeManagementAppServiceException;

	public void writingInExcel() throws EmployeeManagementAppServiceException;

	public List<String> readingFromExcel() throws EmployeeManagementAppServiceException;

}
